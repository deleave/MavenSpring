create
    definer = root@localhost procedure myp4(IN beautyName varchar(20), OUT boyName varchar(20))
begin
    select bo.boyName into boyName
           from boys bo
    right join beauty be on bo.id=be.boyfriend_id
    where be.name=beautyName;
end;

