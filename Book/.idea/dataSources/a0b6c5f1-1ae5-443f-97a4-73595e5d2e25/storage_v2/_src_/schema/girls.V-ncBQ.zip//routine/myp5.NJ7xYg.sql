create
    definer = root@localhost procedure myp5(INOUT a int, INOUT b int)
begin
    set a=a*4;
    set b=b*8;
end;

