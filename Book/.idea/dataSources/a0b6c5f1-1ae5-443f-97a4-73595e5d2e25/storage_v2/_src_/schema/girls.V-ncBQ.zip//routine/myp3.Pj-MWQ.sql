create
    definer = root@localhost procedure myp3(IN beautyName varchar(20))
begin
    select *
           from boys bo
    right join beauty be on bo.id=be.boyfriend_id
    where be.name=beautyName;
end;

