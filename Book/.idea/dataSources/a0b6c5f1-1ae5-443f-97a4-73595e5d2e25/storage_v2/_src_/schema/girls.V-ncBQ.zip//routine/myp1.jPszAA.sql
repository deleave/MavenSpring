create
    definer = root@localhost procedure myp1()
begin
    insert into admin(id, username, password) VALUES (1,'root','1234');
    insert into admin(id, username, password) values (2,'localhost','3456');
    insert into admin(id, username, password) values (3,'user','5678');
    insert into admin(id, username, password) values (4,'service','8907');
    insert into admin(id, username, password) values (5,'console','35633');
end;

