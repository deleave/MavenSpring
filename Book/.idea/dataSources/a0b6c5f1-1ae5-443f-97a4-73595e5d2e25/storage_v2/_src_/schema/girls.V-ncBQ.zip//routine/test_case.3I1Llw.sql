create
    definer = root@localhost procedure test_case(IN score int)
begin
    case
        when score<=100 and score>=90 then select 'A';
        when score>=80 then select 'B';
        when score>=70 then select 'C';
        when score>=60 then select 'D';
        else select 'E';
        end case ;
end;

