create definer = root@localhost view mv3 as
select `myemployees`.`employees`.`last_name` AS `last_name`, `myemployees`.`employees`.`employee_id` AS `employee_id`
from `myemployees`.`employees`;

