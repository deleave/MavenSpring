create
    definer = root@localhost function test_if(score int) returns char
begin
    if score<=100 and score>=90 then return 'A';
        elseif score>=60 then return 'B';
    else return 'D';
        end if;
end;

