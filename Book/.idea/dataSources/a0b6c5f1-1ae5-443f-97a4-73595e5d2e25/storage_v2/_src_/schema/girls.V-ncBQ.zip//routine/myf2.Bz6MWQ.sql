create
    definer = root@localhost function myf2(employee_Name varchar(20)) returns int
begin
    declare s int;
    select salary into s
        from myemployees.employees e
            where employee_Name=e.last_name;
    return s;
end;

