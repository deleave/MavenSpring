create
    definer = root@localhost procedure pro_while(IN insertCount int)
begin
    declare i int default 1;
    a:while i<=insertCount do
        insert into admin(username, password) values (concat('rot',i),'786');
        if i>=20 then leave a;
        end if;
        set i=i+1;
        end while a;
end;

