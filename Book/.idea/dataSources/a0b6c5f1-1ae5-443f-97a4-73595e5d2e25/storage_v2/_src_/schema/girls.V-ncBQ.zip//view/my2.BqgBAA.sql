create definer = root@localhost view my2 as
select `myemployees`.`employees`.`employee_id`    AS `employee_id`,
       `myemployees`.`employees`.`first_name`     AS `first_name`,
       `myemployees`.`employees`.`last_name`      AS `last_name`,
       `myemployees`.`employees`.`email`          AS `email`,
       `myemployees`.`employees`.`phone_number`   AS `phone_number`,
       `myemployees`.`employees`.`job_id`         AS `job_id`,
       `myemployees`.`employees`.`salary`         AS `salary`,
       `myemployees`.`employees`.`commission_pct` AS `commission_pct`,
       `myemployees`.`employees`.`manager_id`     AS `manager_id`,
       `myemployees`.`employees`.`department_id`  AS `department_id`,
       `myemployees`.`employees`.`hiredate`       AS `hiredate`
from `myemployees`.`employees`
where (`myemployees`.`employees`.`salary` < 10000);

